<li class="text-[15px] <?php echo e($isActive ? 'active-submenu' : 'submenu'); ?>">
    <a href="<?php echo e($url ?? ''); ?>" class="w-full"><?php echo e($name); ?></a>
</li>
<?php /**PATH C:\xampp\htdocs\online-shopping\vendor\dd4you\dpanel\src/resources/views/components/sidebar/dropdown-item.blade.php ENDPATH**/ ?>