<script>
    let url = "<?php echo request()->url(); ?>";
    let full_url = new URL("<?php echo request()->fullUrl(); ?>");
    let params = new URLSearchParams(full_url.search);

    const generateUrl = (object) => {
        for (const key in object) {
            if (object.hasOwnProperty.call(object, key)) {

                if (params.has(key)) params.delete(key);

                object[key] != null && object[key] != '' ? params.append(key, object[key]) : params.delete(key);
            }
        }
        return url + '?' + params.toString();
    };
</script>
<?php /**PATH C:\xampp\htdocs\online-shopping\resources\views/components/url-generator-js.blade.php ENDPATH**/ ?>