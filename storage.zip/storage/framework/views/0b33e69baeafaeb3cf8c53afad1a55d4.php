<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.theme.default.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $(".banner-carousel").owlCarousel({
                loop:true,
                margin:10,
                nav:false,
                dots:false,
                responsiveClass:true,
                responsive:{
                    0:{
                        items: 1,
                    },
                    600:{
                        items: 1,
                    },
                    1000:{
                        items: 1,
                    }
                }
            });
        });
        $(document).ready(function() {
            $(".coupon-carousel").owlCarousel({
                loop: <?php echo e($coupons->count() <= 7 ? 0 : 1); ?>,
                margin: 10,
                nav: false,
                dots: false,
                autoplay: true,
                autoplayTimeout: 2000,
                autoplayHoverPause: true,
                responsiveClass: false,
                responsive: {
                    0: {
                        items: 1,
                    },
                    600: {
                        items: 1,
                    },
                    1000: {
                        items: 7,
                    }
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body_content'); ?>
    <div>
        <div class="banner-carousel owl-carousel h-min">
            <a href="#"><img src="<?php echo e(asset('dpanel/images/banner1.png')); ?>" alt=""></a>
            <a href="#"><img src="<?php echo e(asset('dpanel/images/banner2.png')); ?>" alt=""></a>
            <a href="#"><img src="<?php echo e(asset('dpanel/images/banner1.png')); ?>" alt=""></a>
            <a href="#"><img src="<?php echo e(asset('dpanel/images/banner2.png')); ?>" alt=""></a>
            <a href="#"><img src="<?php echo e(asset('dpanel/images/banner1.png')); ?>" alt=""></a>

        </div>
    </div>

    <section class="px-6 md:px-20 mt-6">
        <h3 class="text-gray-800 font-medium mb-2">Flash Sale</h3>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->variant->isNotEmpty()): ?>
                    <?php if (isset($component)) { $__componentOriginale95a270accfadada0901c28612b7c03d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale95a270accfadada0901c28612b7c03d = $attributes; } ?>
<?php $component = App\View\Components\Product\Card1::resolve(['product' => $item] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product.card1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Product\Card1::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale95a270accfadada0901c28612b7c03d)): ?>
<?php $attributes = $__attributesOriginale95a270accfadada0901c28612b7c03d; ?>
<?php unset($__attributesOriginale95a270accfadada0901c28612b7c03d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale95a270accfadada0901c28612b7c03d)): ?>
<?php $component = $__componentOriginale95a270accfadada0901c28612b7c03d; ?>
<?php unset($__componentOriginale95a270accfadada0901c28612b7c03d); ?>
<?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <section class="px-6 md:px-20 mt-10 mb-6">
        <div class="coupon-carousel owl-carousel flex flex-wrap gap-6">
            <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-md shadow mb-2 flex justify-between items-center gap-3">
                    <div class="flex flex-col pl-3 py-1">
                        <span class="text-gray-400 leading-5">New Coupon</span>
                        <strong class="text-orange-500">#<?php echo e($item->code); ?></strong>
                    </div>

                    <div class="bg-violet-600 w-14 font-medium text-white p-3 rounded-r-md">
                        <?php if($item->type == 'Percentage'): ?>
                            <?php echo e($item->value); ?>% Off
                        <?php else: ?>
                            $<?php echo e($item->value); ?> Off
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <section class="px-6 md:px-20 mt-8">
        <div class="flex items-center justify-between">
            <div class="flex gap-2">
                <h3 class="text-gray-800 font-medium underline mb-2">Best Seller</h3>
                <h3 class="text-gray-800 font-medium mb-2">New Product</h3>
            </div>
            <a href="<?php echo e(route('products')); ?>" class="text-violet-600 font-medium mb-2">All Product</a>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->variant->isNotEmpty()): ?>
                    <?php if (isset($component)) { $__componentOriginale95a270accfadada0901c28612b7c03d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale95a270accfadada0901c28612b7c03d = $attributes; } ?>
<?php $component = App\View\Components\Product\Card1::resolve(['product' => $item] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product.card1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Product\Card1::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale95a270accfadada0901c28612b7c03d)): ?>
<?php $attributes = $__attributesOriginale95a270accfadada0901c28612b7c03d; ?>
<?php unset($__attributesOriginale95a270accfadada0901c28612b7c03d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale95a270accfadada0901c28612b7c03d)): ?>
<?php $component = $__componentOriginale95a270accfadada0901c28612b7c03d; ?>
<?php unset($__componentOriginale95a270accfadada0901c28612b7c03d); ?>
<?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online-shopping\resources\views/welcome.blade.php ENDPATH**/ ?>