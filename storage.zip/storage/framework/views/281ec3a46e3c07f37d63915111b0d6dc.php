<?php $__env->startSection('title', 'DPanel Login'); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        // cuteAlert({
        //     type: "success",
        //     title: "Success Title",
        //     message: "Success Message",
        //     buttonText: "Okay"

        //     type: "question",
        //     title: "Confirm Title",
        //     message: "Confirm Message",
        //     confirmText: "Okay",
        //     cancelText: "Cancel"
        // })
        // cuteToast({
        //     type: "info", // or 'success', 'info', 'error', 'warning'
        //     message: "Checking credentials...",
        //     timer: 7500
        // }).then(() => {
        //     cuteToast({
        //         type: "success", // or 'success', 'info', 'error', 'warning'
        //         message: "Login success",
        //     })
        // })
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body_content'); ?>
    <div class="flex items-center justify-center min-h-screen">
        <div class="relative w-11/12 md:w-1/4 mx-auto bg-white p-3 rounded-md shadow-lg">
            <h1 class="text-2xl font-medium text-center ">DPanel Login</h1>
            <form action="<?php echo e(route(config('dpanel.prefix') . '.login')); ?>" method="post"
                class="grid grid-cols-1 gap-4 md:gap-3 mt-6 mb-2">

                <?php if (isset($component)) { $__componentOriginal64e5e2d44a8916a345874c792173c93d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal64e5e2d44a8916a345874c792173c93d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.input-error-msg','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::input-error-msg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal64e5e2d44a8916a345874c792173c93d)): ?>
<?php $attributes = $__attributesOriginal64e5e2d44a8916a345874c792173c93d; ?>
<?php unset($__attributesOriginal64e5e2d44a8916a345874c792173c93d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal64e5e2d44a8916a345874c792173c93d)): ?>
<?php $component = $__componentOriginal64e5e2d44a8916a345874c792173c93d; ?>
<?php unset($__componentOriginal64e5e2d44a8916a345874c792173c93d); ?>
<?php endif; ?>

                <?php echo csrf_field(); ?>
                <div>
                    <label class="font-medium">Username</label>
                    <input type="text" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>"
                        class="w-full bg-transparent px-2 py-1 border border-slate-300 rounded focus:outline-none" required>
                </div>
                <div>
                    <label class="font-medium">Password</label>
                    <input type="password" name="password" placeholder="Password"
                        class="w-full bg-transparent px-2 py-1 border border-slate-300 rounded focus:outline-none" required>
                </div>

                <button
                    class="px-2 py-1 mt-4 shadow-md rounded focus:outline-none text-white bg-violet-500 hover:bg-violet-600 duration-300 font-medium">Login</button>
            </form>
            <a href="<?php echo e(route(config('dpanel.prefix') . '.forgot')); ?>"
                class="text-sm text-gray-400 hover:text-blue-500 duration-300">Forgot
                Password?</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dpanel::auth.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online-shopping\vendor\dd4you\dpanel\src/resources/views/auth/login.blade.php ENDPATH**/ ?>