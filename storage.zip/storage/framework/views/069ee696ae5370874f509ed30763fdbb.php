<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="<?php echo e(asset('dd4you/dpanel/js/cute-alert/style.css')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo $__env->yieldPushContent('css'); ?>

</head>

<body class="w-full flex flex-no-wrap bg-gray-100">

    <header class="fixed w-full bg-gray-800 text-white px-3 flex items-center shadow-lg gap-3 h-14 z-50">
        <span>
            <i onclick="openSidebar(this)" class='bx bx-menu-alt-left cursor-pointer  text-white text-3xl'></i>
        </span>
        <div class="w-full flex justify-between items-center">
            <span class="font-medium">Dashboard</span>
            <div class="flex items-center gap-2">
                <span class="font-medium">Logout</span>
                <a href="<?php echo e(route(config('dpanel.prefix') . '.logout')); ?>"><i
                        class='bx bx-log-in-circle cursor-pointer  text-gray-300 hover:text-red-500 duration-300 text-2xl'></i></a>
            </div>
        </div>
    </header>

    <?php if (isset($component)) { $__componentOriginal4210655b27276f350142801a0c23083b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4210655b27276f350142801a0c23083b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.sidebar.container','data' => ['name' => 'DD Admin']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::sidebar.container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'DD Admin']); ?>

        <?php if (isset($component)) { $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.sidebar.item','data' => ['name' => 'Dashboard','icon' => 'bx-home','url' => ''.e(route(config('dpanel.prefix') . '.dashboard')).'','isActive' => ''.e(request()->segment(2) == 'dashboard').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::sidebar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Dashboard','icon' => 'bx-home','url' => ''.e(route(config('dpanel.prefix') . '.dashboard')).'','isActive' => ''.e(request()->segment(2) == 'dashboard').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $attributes = $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $component = $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>
            
            <?php if (isset($component)) { $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.sidebar.item','data' => ['name' => 'Brand','icon' => 'bx-category','url' => ''.e(route('dpanel.brand.index')).'','isActive' => ''.e(request()->segment(2) == 'brand').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::sidebar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Brand','icon' => 'bx-category','url' => ''.e(route('dpanel.brand.index')).'','isActive' => ''.e(request()->segment(2) == 'brand').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $attributes = $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $component = $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.sidebar.item','data' => ['name' => 'Categories','icon' => 'bx-category','url' => ''.e(route('dpanel.category.index')).'','isActive' => ''.e(request()->segment(2) == 'category').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::sidebar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Categories','icon' => 'bx-category','url' => ''.e(route('dpanel.category.index')).'','isActive' => ''.e(request()->segment(2) == 'category').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $attributes = $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $component = $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.sidebar.item','data' => ['name' => 'Sizes','icon' => 'bx-category','url' => ''.e(route('dpanel.size.index')).'','isActive' => ''.e(request()->segment(2) == 'size').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::sidebar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Sizes','icon' => 'bx-category','url' => ''.e(route('dpanel.size.index')).'','isActive' => ''.e(request()->segment(2) == 'size').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $attributes = $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $component = $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.sidebar.item','data' => ['name' => 'Colors','icon' => 'bx-palette','url' => ''.e(route('dpanel.color.index')).'','isActive' => ''.e(request()->segment(2) == 'color').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::sidebar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Colors','icon' => 'bx-palette','url' => ''.e(route('dpanel.color.index')).'','isActive' => ''.e(request()->segment(2) == 'color').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $attributes = $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $component = $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.sidebar.item','data' => ['name' => 'Products','icon' => 'bx-shopping-bag','url' => ''.e(route('dpanel.product.index')).'','isActive' => ''.e(request()->segment(2) == 'product').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::sidebar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Products','icon' => 'bx-shopping-bag','url' => ''.e(route('dpanel.product.index')).'','isActive' => ''.e(request()->segment(2) == 'product').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $attributes = $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $component = $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.sidebar.item','data' => ['name' => 'Coupons','icon' => 'bxs-discount','url' => ''.e(route('dpanel.coupon.index')).'','isActive' => ''.e(request()->segment(2) == 'coupon').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::sidebar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Coupons','icon' => 'bxs-discount','url' => ''.e(route('dpanel.coupon.index')).'','isActive' => ''.e(request()->segment(2) == 'coupon').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $attributes = $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $component = $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.sidebar.item','data' => ['name' => 'Orders','icon' => 'bxs-discount','url' => ''.e(route('dpanel.order.index')).'','isActive' => ''.e(request()->segment(2) == 'order').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::sidebar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Orders','icon' => 'bxs-discount','url' => ''.e(route('dpanel.order.index')).'','isActive' => ''.e(request()->segment(2) == 'order').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $attributes = $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $component = $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>
            

        

        
        <?php if(Schema::hasTable('global_settings')): ?>
            <?php if (isset($component)) { $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.sidebar.item','data' => ['name' => 'Global Settings','icon' => 'bx-cog','url' => ''.e(route(config('dpanel.prefix') . '.global-settings.index')).'','isActive' => ''.e(request()->segment(2) == 'global-settings').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::sidebar.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Global Settings','icon' => 'bx-cog','url' => ''.e(route(config('dpanel.prefix') . '.global-settings.index')).'','isActive' => ''.e(request()->segment(2) == 'global-settings').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $attributes = $__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__attributesOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a)): ?>
<?php $component = $__componentOriginalc5a26414ee9486f2ae741c9d12f7249a; ?>
<?php unset($__componentOriginalc5a26414ee9486f2ae741c9d12f7249a); ?>
<?php endif; ?>
        <?php endif; ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4210655b27276f350142801a0c23083b)): ?>
<?php $attributes = $__attributesOriginal4210655b27276f350142801a0c23083b; ?>
<?php unset($__attributesOriginal4210655b27276f350142801a0c23083b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4210655b27276f350142801a0c23083b)): ?>
<?php $component = $__componentOriginal4210655b27276f350142801a0c23083b; ?>
<?php unset($__componentOriginal4210655b27276f350142801a0c23083b); ?>
<?php endif; ?>



    <main class="dd-main">
        <div class="px-4 py-6">
            <?php echo $__env->yieldContent('body_content'); ?>
        </div>
    </main>

    <script src="<?php echo e(asset('dd4you/dpanel/js/dd4you.js')); ?>"></script>
    <script src="<?php echo e(asset('dd4you/dpanel/js/cute-alert/cute-alert.js')); ?>"></script>
    <script src="<?php echo e(asset('dd4you/dpanel/js/jquery-3.7.1.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script>
        <?php if(Session::has('success')): ?>
            cuteToast({
                type: "success",
                message: "<?php echo e(session('success')); ?>",
            })
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            cuteToast({
                type: "error",
                message: "<?php echo e(session('error')); ?>",
            })
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
            cuteToast({
                type: "info",
                message: "<?php echo e(session('info')); ?>",
            })
        <?php endif; ?>

        <?php if(Session::has('warning')): ?>
            cuteToast({
                type: "warning",
                message: "<?php echo e(session('warning')); ?>",
            })
        <?php endif; ?>

        const openSidebar = (e) => {
            // e.classList.remove();
            // e.classList.add('bxl-xing');
            document.querySelector('.dd-aside').classList.toggle('left-0');
            if (!isMobileResponsive()) document.querySelector('.dd-main').classList.toggle('w-[calc(100%-220px)]');
        }

        if (isMobileResponsive()) {
            document.querySelector('.dd-aside').classList.remove('left-0')
            document.querySelector('.dd-main').classList.remove('w-[calc(100%-220px)]')
        } else {
            document.querySelector('.dd-aside').classList.add('left-0')
            document.querySelector('.dd-main').classList.add('w-[calc(100%-220px)]')
        }
        window.addEventListener('resize', function() {
            if (isMobileResponsive()) {
                document.querySelector('.dd-aside').classList.remove('left-0')
                document.querySelector('.dd-main').classList.remove('w-[calc(100%-220px)]')
            } else {
                document.querySelector('.dd-aside').classList.add('left-0')
                document.querySelector('.dd-main').classList.add('w-[calc(100%-220px)]')
            }
        });

        const toggleSubmenu = (e) => {
            let ele = e.nextElementSibling;
            ele.classList.toggle('show');
            e.querySelector('.bx-chevron-right').classList.toggle('bx-rotate-90');
            ele.style.height = ele.style.height ? null : ele.scrollHeight + 'px';
        }
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\online-shopping\resources\views/dpanel/layouts/app.blade.php ENDPATH**/ ?>