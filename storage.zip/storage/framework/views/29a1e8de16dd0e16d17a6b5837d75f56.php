<div class="flex flex-col items-center ">

    <div onclick="toggleSubmenu(this)" class="w-full flex justify-between <?php echo e($isActive ? 'active-menu' : 'menu'); ?>">
        <div class="flex items-center">
            <i class='bx <?php echo e($icon); ?>'></i>
            <span class="text-[15px] ml-1.5"><?php echo e($name); ?></span>
        </div>
        <i class='bx bx-chevron-right duration-300 '></i>
    </div>

    <ul class="w-11/12 ml-auto dropdown">

        <?php echo e($slot); ?>


    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\online-shopping\vendor\dd4you\dpanel\src/resources/views/components/sidebar/dropdown.blade.php ENDPATH**/ ?>