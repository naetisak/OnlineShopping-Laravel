<script>
    setTimeout(() => {
        Highcharts
            .chart('<?php echo e($chartId); ?>', {
                chart: {
                    // backgroundColor: '#1f2937',
                    type: 'column',
                    options3d: {
                        enabled: true,
                        alpha: 10,
                        beta: 15,
                        depth: 50,
                        viewDistance: 25
                    }
                },
                xAxis: {
                    categories: <?php echo json_encode($chartNames, 15, 512) ?>,
                },
                yAxis: {
                    title: {
                        text: "<?php echo e($chartAxisTitleY ?? ''); ?>",
                        // style: {
                        //     "color": '#a5a5a5',
                        // }
                    }
                },
                tooltip: {
                    headerFormat: '<b>{point.key} <?php echo e($chartTooltip ?? ''); ?></b><br>',
                    pointFormat: '<?php echo e($chartTooltip ?? ''); ?>: {point.y}'
                },
                title: {
                    text: "<?php echo e($chartTitle ?? ''); ?>",
                    // style: {
                    //     "color": '#ffffff',
                    // }
                },
                legend: {
                    enabled: false
                },
                plotOptions: {
                    column: {
                        depth: 25
                    }
                },
                series: [{
                    data: <?php echo json_encode($chartData, 15, 512) ?>,
                    colorByPoint: true
                }]
            });
    }, 1000);
</script>
<div id="<?php echo e($chartId); ?>" class="w-full bg-white rounded-md shadow-lg hover:shadow-xl duration-300"></div>
<?php /**PATH C:\xampp\htdocs\online-shopping\vendor\dd4you\dpanel\src/resources/views/components/chart/column.blade.php ENDPATH**/ ?>