<?php $__env->startSection('body_content'); ?>
    <section class="px-6 md:px-20 mt-6 min-h-screen">
        <h1 class="text-5xl font-bold text-center drop-shadow-md text-black py-12">Wishlist</h1>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex gap-4">
                    <div class="bg-gray-100 rounded shadow p-2">
                        <img class="w-20" src="<?php echo e(asset('storage/' . $item->oldestImage->path)); ?>" alt="">
                    </div>
                    <div class="flex flex-col gap-0.5">
                        <h3 class="text-lg font-medium text-gray-800"><?php echo e($item->title); ?></h3>
                        <div class="text-gray-400 text-sm flex items-center gap-2">
                            <p class="flex items-center gap-1">
                                Color:
                                <span style="background-color: <?php echo e($item->latestVariant->color->code); ?>"
                                    class="w-4 h-4 rounded-full">&nbsp;</span>
                            </p>
                            <p>Size: <?php echo e($item->latestVariant->size->code); ?></p>
                        </div>
                        <p class="text-black text-lg font-bold">₹<?php echo e($item->latestVariant->selling_price); ?>

                            <sub class="text-sm font-normal text-red-500">₹<?php echo e($item->latestVariant->mrp); ?>

                                <?php
                                    $discount = round((($item->latestVariant->mrp - $item->latestVariant->selling_price) / $item->latestVariant->mrp) * 100, 2);
                                ?>
                                <span class="text-green-400">(<?php echo e($discount); ?>% off)</span>
                            </sub>
                        </p>
                        <div class="flex items-center gap-6">
                            <a href="<?php echo e(route('product_detail', $item->id)); ?>"
                                class="text-violet-600 font-bold uppercase">Buy Now</a>
                            <button onclick="toggleWishlist(this, '<?php echo e($item->id); ?>', true)"
                                class="text-gray-400 uppercase">Remove</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="md:col-span-3 flex flex-col justify-center items-center gap-3">
                    <img src="<?php echo e(asset('images/empty_cart.png')); ?>" alt="">
                    <h1 class="text-2xl font-bold text-gray-800">Your wishlist is empty</h1>
                    <p class="text-gray-400"></p>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online-shopping\resources\views/wishlist.blade.php ENDPATH**/ ?>