<a href="<?php echo e($url ?? ''); ?>" class="<?php echo e($isActive ? 'active-menu' : 'menu'); ?>">
    <i class='bx <?php echo e($icon); ?>'></i>
    <span class="text-[15px] ml-2"><?php echo e($name); ?></span>
</a>
<?php /**PATH C:\xampp\htdocs\online-shopping\vendor\dd4you\dpanel\src/resources/views/components/sidebar/item.blade.php ENDPATH**/ ?>