<div id="<?php echo e($sheetId); ?>" class="bottom-sheet">

    <div class="bottom-sheet-content <?php echo e($bsPosition ?? 'B'); ?> px-3 pt-3 pb-12">

        <div class="absolute right-3">
            <i onclick="closeBottomSheet(this)"
                class='bx bx-x border border-red-500 w-6 h-6 text-2xl flex items-center justify-center bg-red-50 rounded-full text-red-500 cursor-pointer'></i>
        </div>

        <h1 id="<?php echo e($sheetId); ?>-title" class="text-center font-bold uppercase"><?php echo e($title); ?></h1>
        <hr class="my-2">

        <div class="px-3 md:px-0">
            <?php echo e($slot); ?>

        </div>

    </div>

</div>
<?php /**PATH C:\xampp\htdocs\online-shopping\vendor\dd4you\dpanel\src/resources/views/components/modal/bottom-sheet.blade.php ENDPATH**/ ?>