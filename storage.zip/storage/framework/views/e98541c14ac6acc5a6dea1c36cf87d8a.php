<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('dd4you/dpanel/js/cute-alert/style.css')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="bg-gray-100 text-gray-800">

    <?php echo $__env->yieldContent('body_content'); ?>

    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

    <script src="<?php echo e(asset('dd4you/dpanel/js/cute-alert/cute-alert.js')); ?>"></script>

    <script>
        <?php if(Session::has('success')): ?>
            cuteToast({
                type: "success",
                message: "<?php echo e(session('success')); ?>",
            })
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            cuteToast({
                type: "error",
                message: "<?php echo e(session('error')); ?>",
            })
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
            cuteToast({
                type: "info",
                message: "<?php echo e(session('info')); ?>",
            })
        <?php endif; ?>

        <?php if(Session::has('warning')): ?>
            cuteToast({
                type: "warning",
                message: "<?php echo e(session('warning')); ?>",
            })
        <?php endif; ?>
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\online-shopping\vendor\dd4you\dpanel\src/resources/views/auth/layout.blade.php ENDPATH**/ ?>