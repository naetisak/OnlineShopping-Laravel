<script src="//code.highcharts.com/highcharts.js"></script>
<script src="//code.highcharts.com/highcharts-3d.js"></script>
<?php echo e($slot); ?>

<script src="//code.highcharts.com/modules/accessibility.js"></script>

<style>
    .highcharts-credits {
        opacity: 0;
        visibility: hidden;
    }
</style>
<?php /**PATH C:\xampp\htdocs\online-shopping\vendor\dd4you\dpanel\src/resources/views/components/chart/js.blade.php ENDPATH**/ ?>