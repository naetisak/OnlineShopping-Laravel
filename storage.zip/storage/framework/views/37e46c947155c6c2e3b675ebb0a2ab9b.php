<aside class="dd-aside">
    <div class="text-xl">

        <div class="flex flex-col gap-4 mt-16"><?php echo e($slot); ?></div>

    </div>
</aside>
<?php /**PATH C:\xampp\htdocs\online-shopping\vendor\dd4you\dpanel\src/resources/views/components/sidebar/container.blade.php ENDPATH**/ ?>