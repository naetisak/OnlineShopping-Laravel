<script>
    setTimeout(() => {
        Highcharts.chart('<?php echo e($chartId); ?>', {
            chart: {
                // backgroundColor: '#1f2937',
                type: 'pie',
                options3d: {
                    enabled: true,
                    alpha: 45
                }
            },
            title: {
                text: "<?php echo e($chartTitle ?? ''); ?>",
                // style: {
                //     "color": '#ffffff',
                // }
            },
            plotOptions: {
                pie: {
                    innerSize: 100,
                    depth: 45
                }
            },
            series: [{
                name: '<?php echo e($chartName); ?>',
                data: <?php echo json_encode($chartData, 15, 512) ?>,
            }]
        });
    }, 1000);
</script>
<div id="<?php echo e($chartId); ?>" class="w-full bg-white rounded-md shadow-lg hover:shadow-xl duration-300"></div>
<?php /**PATH C:\xampp\htdocs\online-shopping\vendor\dd4you\dpanel\src/resources/views/components/chart/donut.blade.php ENDPATH**/ ?>