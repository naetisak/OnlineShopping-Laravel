<?php $__env->startSection('title', 'Forgot Password'); ?>

<?php $__env->startSection('body_content'); ?>
    <div class="flex items-center justify-center min-h-screen">
        <div class="relative w-11/12 md:w-1/4 mx-auto bg-white p-3 rounded-md shadow-lg">
            <h1 class="text-2xl font-medium text-center ">Forgot Password</h1>

            <form action="" method="post" class="grid grid-cols-1 gap-4 md:gap-3 mt-6 mb-2">

                <?php if (isset($component)) { $__componentOriginal64e5e2d44a8916a345874c792173c93d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal64e5e2d44a8916a345874c792173c93d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.input-error-msg','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::input-error-msg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal64e5e2d44a8916a345874c792173c93d)): ?>
<?php $attributes = $__attributesOriginal64e5e2d44a8916a345874c792173c93d; ?>
<?php unset($__attributesOriginal64e5e2d44a8916a345874c792173c93d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal64e5e2d44a8916a345874c792173c93d)): ?>
<?php $component = $__componentOriginal64e5e2d44a8916a345874c792173c93d; ?>
<?php unset($__componentOriginal64e5e2d44a8916a345874c792173c93d); ?>
<?php endif; ?>

                <?php echo csrf_field(); ?>
                <div>
                    <label class="font-medium">Email</label>
                    <input type="text" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email Address"
                        class="w-full bg-transparent px-2 py-1 border border-slate-300 rounded focus:outline-none">
                </div>

                <button
                    class="px-2 py-1 mt-4 shadow-md rounded focus:outline-none text-white bg-violet-500 hover:bg-violet-600 duration-300 font-medium">Send
                    Reset Email</button>
            </form>
            <a href="<?php echo e(route(config('dpanel.prefix') . '.login')); ?>"
                class="text-sm text-gray-400 hover:text-blue-500 duration-300">Login</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dpanel::auth.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online-shopping\vendor\dd4you\dpanel\src/resources/views/auth/forgot.blade.php ENDPATH**/ ?>