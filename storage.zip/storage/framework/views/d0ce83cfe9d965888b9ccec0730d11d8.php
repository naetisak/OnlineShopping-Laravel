

<?php $__env->startSection('title', 'Coupons'); ?>

<?php $__env->startPush('scripts'); ?>
    <script>

        const updateStatus = (e, id) =>{
            window.location.href = `${window.location.href}/status/${id}/${e.value}`;
        }
        const editCoupon = (item,from,till)=>{
            item = JSON.parse(item);
            document.getElementById("edit-form").action = `${window.location.href}/${item.id}`;
            document.getElementById('code').value = item.code;
            document.getElementById('type').value = item.type;
            document.getElementById('value').value = item.value;
            document.getElementById('min_cart_amount').value = item.min_cart_amount;
            document.getElementById('from_valid').value = from;
            document.getElementById('till_valid').value = till;
            showBottomSheet('bottomSheetUpdate')
        }
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body_content'); ?>
    <div class="bg-gray-800 flex justify-between items-center rounded-l pl-2 mb-3 ">
        <p class="text-white font-medium text-lg ">Coupons</p>
        <button onclick="showBottomSheet('bottomSheet')" class="bg-violet-500 text-white py-1 px-2 rounded-r ">Create</button>
    </div>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 text-red-500 px-2 py-1 rounded border border-red-500 mb-3">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <div class="w-full flex flex-col">
        <div class="overflow-x-auto">
            <div class="align-middle inline-block min-w-full">
                <div class=" shadow overflow-hidden border border-gray-400 sm:rounded-lg">
                    <table class="min-w-full divide-y divide-gray-600">
                        <thead class="bg-gray-800">
                            <tr>

                                <th scope="col" 
                                    class="pl-3 py-3 text-left w-12 text-xs font-medium text-gray-200 tracking-wider">
                                    #
                                </th>

                                <th scope="col" 
                                    class="pl-3 py-3 text-left text-xs font-medium text-gray-200 tracking-wider">
                                    Coupon
                                </th>

                                <th scope="col" 
                                    class="pl-3 py-3 text-left text-xs font-medium text-gray-200 tracking-wider">
                                    Total
                                </th>

                                <th scope="col" 
                                    class="pl-3 py-3 text-left text-xs font-medium text-gray-200 tracking-wider">
                                    Discount
                                </th>

                                <th scope="col" 
                                    class="pl-3 py-3 text-left text-xs font-medium text-gray-200 tracking-wider">
                                    Pay
                                </th>

                                <th scope="col" 
                                    class="pl-3 py-3 text-left text-xs font-medium text-gray-200 tracking-wider">
                                    Payment Status
                                </th>


                                <th scope="col" 
                                    class="px-3 py-3 text-text-center text-xs font-medium text-gray-200 tracking-wider">
                                    Action
                                </th>
                            </tr>
                        </thead>

                         <tbody class="bg-gray-700 divide-y divide-gray-600">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="pl-3 py-1">
                                        <div class="text-sm text-gray-200">
                                            <?php echo e($data->perPage() * ($data->currentPage() - 1) + $loop->iteration); ?>

                                        </div>
                                    </td>

                                    <td class="pl-3 py-3">
                                        <div class="text-sm text-gray-200"><?php echo e($item->coupon->code ?? ''); ?></div>
                                    </td>

                                    <td class="pl-3 py-3">
                                        <div class="text-sm text-gray-200">$<?php echo e($item->total_amount); ?></div>
                                    </td>

                                    <td class="pl-3 py-3">
                                        <div class="text-sm text-gray-200">$<?php echo e($item->discount_amount); ?></div>
                                    </td>

                                    <td class="pl-3 py-3">
                                        <div class="text-sm text-gray-200">$<?php echo e($item->total_amount - $item->discount_amount); ?></div>
                                    </td>

                                    <td class="pl-3 py-3">
                                        <div class="text-sm text-gray-200"><?php echo e($item->payment_status); ?></div>
                                    </td>

                                    <td class="flex px-4 py-3 justify-center text-lg">
                                        <select onchange="updateStatus(this,'<?php echo e($item->id); ?>')"
                                             class="border rounded focus:outline-none">
                                            <option value="PENDING" <?php if($item->status == 'PENDING'): echo 'selected'; endif; ?>>PENDING</option>
                                            <option value="PAIN OUT" <?php if($item->status == 'PAIN OUT'): echo 'selected'; endif; ?>>PAIN OUT</option>
                                            <option value="DISPATCHED" <?php if($item->status == 'DISPATCHED'): echo 'selected'; endif; ?>>DISPATCHED</option>
                                            <option value="ON WAY" <?php if($item->status == 'ON WAY'): echo 'selected'; endif; ?>>ON WAY</option>
                                            <option value="DELIVERED" <?php if($item->status == 'DELIVERED'): echo 'selected'; endif; ?>>DELIVERED</option>
                                        </select>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                         </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php echo e($data->links()); ?>

    </div>

    <?php if (isset($component)) { $__componentOriginale7dcbfe9eba53c3433f2ff6a8759147e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale7dcbfe9eba53c3433f2ff6a8759147e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.modal.bottom-sheet','data' => ['sheetId' => 'bottomSheet','title' => 'New Coupon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::modal.bottom-sheet'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['sheetId' => 'bottomSheet','title' => 'New Coupon']); ?>
        <div class="flex justify-center items-center min-h-[30vh] md:min-h-[50vh]">
            <form action="<?php echo e(route('dpanel.coupon.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="grid grid-cols-1 gap-3">
                    <div>
                        <label>Coupon Code<span class="text-red-500 font-bold">*</span></label>
                        <input type="text" name="code" maxlength="50" required placeholder="Enter Coupon Code" 
                            class="w-full bg-transparent border border-gray-500 rounded py-0.5 px-2 focus:outline-none">
                    </div>

                    <div>
                        <label>Coupon Type<span class="text-red-500 font-bold">*</span></label>
                        <select name="type" class="w-full bg-gray-100 border border-gray-500 rounded py-0.5 px-2 focus:outline-none">
                            <option value="">select type</option>
                            <option value="Fixed">Fixed</option>
                            <option value="Percentage">Percentage</option>
                        </select>
                    </div>

                    <div>
                        <label>Coupon Value<span class="text-red-500 font-bold">*</span></label>
                        <input type="number" name="value" required placeholder="Enter Coupon Value" 
                            class="w-full bg-transparent border border-gray-500 rounded py-0.5 px-2 focus:outline-none">
                    </div>

                    <div>
                        <label>Min Cart Amount</label>
                        <input type="number" name="min_cart_amount" maxlength="50" placeholder="Enter Min Cart Amount" 
                            class="w-full bg-transparent border border-gray-500 rounded py-0.5 px-2 focus:outline-none">
                    </div>

                    <div>
                        <label>Valid From<span class="text-red-500 font-bold">*</span></label>
                        <input type="datetime-local" name="from_valid" required
                            class="w-full bg-transparent border border-gray-500 rounded py-0.5 px-2 focus:outline-none">
                    </div>

                    <div>
                        <label>Valid To<span class="text-red-500 font-bold">*</span></label>
                        <input type="datetime-local" name="till_valid"
                            class="w-full bg-transparent border border-gray-500 rounded py-0.5 px-2 focus:outline-none">
                    </div>

                    <div class="text-center">
                        <button class="bg-indigo-500 text-center text-white py-1 px-2 rounded shadow-md uppercase">Create
                            New
                            Coupon</button>

                    </div>

                </div>
            </form>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale7dcbfe9eba53c3433f2ff6a8759147e)): ?>
<?php $attributes = $__attributesOriginale7dcbfe9eba53c3433f2ff6a8759147e; ?>
<?php unset($__attributesOriginale7dcbfe9eba53c3433f2ff6a8759147e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7dcbfe9eba53c3433f2ff6a8759147e)): ?>
<?php $component = $__componentOriginale7dcbfe9eba53c3433f2ff6a8759147e; ?>
<?php unset($__componentOriginale7dcbfe9eba53c3433f2ff6a8759147e); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginale7dcbfe9eba53c3433f2ff6a8759147e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale7dcbfe9eba53c3433f2ff6a8759147e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.modal.bottom-sheet','data' => ['sheetId' => 'bottomSheetUpdate','title' => 'Update Category']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::modal.bottom-sheet'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['sheetId' => 'bottomSheetUpdate','title' => 'Update Category']); ?>
        <div class="flex justify-center items-center min-h-[30vh] md:min-h-[50vh]">
            <form id="edit-form" action="" method="post">

                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                        <label>Coupon Code<span class="text-red-500 font-bold">*</span></label>
                        <input type="text" name="code" id="code" maxlength="50" required
                            placeholder="Enter Coupon Code"
                            class="w-full bg-transparent border border-gray-500 rounded py-0.5 px-2 focus:outline-none">
                    </div>
                    <div>
                        <label>Coupon Type<span class="text-red-500 font-bold">*</span></label>
                        <select name="type" id="type"
                            class="w-full bg-gray-100 border border-gray-500 rounded py-0.5 px-2 focus:outline-none">
                            <option value="">select type</option>
                            <option value="Fixed">Fixed</option>
                            <option value="Percentage">Percentage</option>
                        </select>
                    </div>
                    <div>
                        <label>Coupon Value<span class="text-red-500 font-bold">*</span></label>
                        <input type="number" id="value" name="value" required placeholder="Enter Coupon Value"
                            class="w-full bg-transparent border border-gray-500 rounded py-0.5 px-2 focus:outline-none">
                    </div>
                    <div>
                        <label>Min Cart Amount</label>
                        <input type="number" id="min_cart_amount" name="min_cart_amount"
                            placeholder="Enter Min Cart Amount"
                            class="w-full bg-transparent border border-gray-500 rounded py-0.5 px-2 focus:outline-none">
                    </div>
                    <div>
                        <label>Valid From<span class="text-red-500 font-bold">*</span></label>
                        <input type="datetime-local" id="from_valid" name="from_valid" required
                            class="w-full bg-transparent border border-gray-500 rounded py-0.5 px-2 focus:outline-none">
                    </div>
                    <div>
                        <label>Valid To<span class="text-red-500 font-bold">*</span></label>
                        <input type="datetime-local" id="till_valid" name="till_valid"
                            class="w-full bg-transparent border border-gray-500 rounded py-0.5 px-2 focus:outline-none">
                    </div>

                    <div>
                        <label>&nbsp;</label>
                        <button
                            class="w-full bg-indigo-500 text-center text-white py-1 px-2 rounded shadow-md uppercase">Update
                            Coupon</button>
                    </div>
                </div>
            </form>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale7dcbfe9eba53c3433f2ff6a8759147e)): ?>
<?php $attributes = $__attributesOriginale7dcbfe9eba53c3433f2ff6a8759147e; ?>
<?php unset($__attributesOriginale7dcbfe9eba53c3433f2ff6a8759147e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7dcbfe9eba53c3433f2ff6a8759147e)): ?>
<?php $component = $__componentOriginale7dcbfe9eba53c3433f2ff6a8759147e; ?>
<?php unset($__componentOriginale7dcbfe9eba53c3433f2ff6a8759147e); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalec2670f24a1e651d637f3a1ec7c44fb4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalec2670f24a1e651d637f3a1ec7c44fb4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'dpanel::components.modal.bottom-sheet-js','data' => ['hideOnClickOutside' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dpanel::modal.bottom-sheet-js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['hideOnClickOutside' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalec2670f24a1e651d637f3a1ec7c44fb4)): ?>
<?php $attributes = $__attributesOriginalec2670f24a1e651d637f3a1ec7c44fb4; ?>
<?php unset($__attributesOriginalec2670f24a1e651d637f3a1ec7c44fb4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalec2670f24a1e651d637f3a1ec7c44fb4)): ?>
<?php $component = $__componentOriginalec2670f24a1e651d637f3a1ec7c44fb4; ?>
<?php unset($__componentOriginalec2670f24a1e651d637f3a1ec7c44fb4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dpanel.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online-shopping\resources\views/dpanel/orders.blade.php ENDPATH**/ ?>