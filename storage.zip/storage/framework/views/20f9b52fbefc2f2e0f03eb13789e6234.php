<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.theme.default.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
    <?php if (isset($component)) { $__componentOriginal1dddf896a7621481ec01e64a744db32e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1dddf896a7621481ec01e64a744db32e = $attributes; } ?>
<?php $component = App\View\Components\UrlGeneratorJs::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('url-generator-js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\UrlGeneratorJs::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1dddf896a7621481ec01e64a744db32e)): ?>
<?php $attributes = $__attributesOriginal1dddf896a7621481ec01e64a744db32e; ?>
<?php unset($__attributesOriginal1dddf896a7621481ec01e64a744db32e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1dddf896a7621481ec01e64a744db32e)): ?>
<?php $component = $__componentOriginal1dddf896a7621481ec01e64a744db32e; ?>
<?php unset($__componentOriginal1dddf896a7621481ec01e64a744db32e); ?>
<?php endif; ?>
    <script>
        $(document).ready(function(){
            $(".owl-carousel").owlCarousel({
                loop:true,
                margin:10,
                nav:false,
                dots:false,
                responsiveClass:true,
                responsive:{
                    0:{
                        items:1,
                    },
                    600:{
                        items:1,
                    },
                    1000:{
                        items:1,
                    }
                }
            });
        });

        const sortBy = (e) => {
            let sb = e.value;
            window.location.href = generateUrl({
                sb
            });
        }

        const search = () => {
            let k = document.getElementById('search_input').value;
            window.location.href = generateUrl({
                k
            });
        }

        const applyFilter = () => {
            let form = document.getElementById('filter-form');
            let formData = new FormData(form);
            let obj = {};

            for (const [key, value] of formData) {
                if (obj.hasOwnProperty(key)) {
                    obj = {
                        ...obj,
                        [key]: `${obj[key]},${value}`
                    }
                } else {
                    obj = {
                        ...obj,
                        [key]: value
                    }
                }
            }

            window.location.href = generateUrl(obj);
        }
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body_content'); ?>

    <div>
        <div class="owl-carousel h-min">
            <a href="#"><img src="<?php echo e(asset('dpanel/images/banner1.png')); ?>" alt=""></a>
            <a href="#"><img src="<?php echo e(asset('dpanel/images/banner2.png')); ?>" alt=""></a>
            <a href="#"><img src="<?php echo e(asset('dpanel/images/banner1.png')); ?>" alt=""></a>
            <a href="#"><img src="<?php echo e(asset('dpanel/images/banner2.png')); ?>" alt=""></a>
            <a href="#"><img src="<?php echo e(asset('dpanel/images/banner1.png')); ?>" alt=""></a>
        </div>
    </div>

    <section class="px-6 md:px-20 mt-6">

        <section class="mt-6 grid grid-cols-1 md:grid-cols-5 gap-6">
            
            <div>
                <form id="filter-form" class="w-full md:w-auto p-3 rounded border border-slate-300">
                    <h3 class="text-xl font-bold text-violet-600 uppercase">Filters</h3>
    
                    
                    <div>
                        <h4 class="text-gray-800 font-medium mb-1">Price</h4>
                        <div class="flex justify-between items-center gap-4">
                            <div class="bg-gray-300 rounded p-1 flex justify-between items-center gap-2">
                                <span class="text-gray-400">From</span>
                                <div class="flex">
                                    <input type="text" name="min" pattern="[0-9]+" value="<?php echo e(request()->min); ?>"
                                         class="w-7 bg-transparent focus:outline-none text-right">
                                    <span class="text-gray-400">$</span>
                                </div>
                            </div>
    
                            <div class="bg-gray-300 rounded p-1 flex justify-between items-center gap-3 ">
                                <span class="text-gray-400">Up to</span>
                                <div class="flex">
                                    <input type="text" name="max" pattern="[0-9]+" value="<?php echo e(request()->max); ?>"
                                         class="w-7 bg-transparent focus:outline-none text-right">
                                    <span class="text-gray-400">$</span>
                                </div>
                            </div>
                        </div> 
                    </div>
                    <hr class="mt-2">
    
                    
                    <div>
                        <h4 class="text-gray-800 font-medium mb-1">Size</h4>
                        <ul class="text-gray-400 text-sm">
                            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="flex gap-2">
                                    <input type="checkbox" name="size" id="size-<?php echo e($item->id); ?>" 
                                    value="<?php echo e($item->id); ?>"
                                    <?php if(request()->size): ?> <?php if(in_array($item->id, explode(',', urldecode(request()->size)))): echo 'checked'; endif; ?> <?php endif; ?>> 
                                    <label class="cursor-pointer" for="size-<?php echo e($item->id); ?>"><?php echo e($item->name); ?>(<?php echo e($item->code); ?>)</label>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="size" value="">
                        </ul>
                    </div>
                    <hr class="mt-2">
    
                    
                    <div>
                        <h4 class="text-gray-800 font-medium mb-1">Color</h4>
                        <ul class="text-gray-400 text-sm flex flex-col gap-2">
                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="flex gap-2">
                                    <input type="checkbox" name="color" id="color-<?php echo e($item->id); ?>" 
                                        value="<?php echo e($item->id); ?>"
                                        <?php if(request()->color): ?> <?php if(in_array($item->id, explode(',', urldecode(request()->color)))): echo 'checked'; endif; ?> <?php endif; ?>>
                                    <label class="cursor-pointer flex gap-1" for="color-<?php echo e($item->id); ?>">
                                        <span style="background-color: <?php echo e($item->code); ?>" 
                                            class="w-4 h-4 flex rounded-full">&nbsp;</span> <?php echo e($item->name); ?>

                                    </label>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <hr class="my-2">
    
                    <div class="flex items-center justify-between">
                        <button type="button" onclick="applyFilter()" 
                            class="bg-violet-600 rounded-md text-white font-medium uppercase text-center py-0.5 px-4">
                            Apply Filter</button>
                        <a href="<?php echo e(route('products')); ?>"><img class="w-7 h-7" 
                                src="<?php echo e(asset('dpanel/images/refresh.png')); ?>" alt=""></a>
                    </div>
                </form>  
            </div>

            
            <div class="md:col-span-4 grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="md:col-span-2 flex items-center px-1.5 text-sm rounded border border-slate-300">
                    <span class="w-6 border-r border-slate-300">
                        <i class='bx bx-search text-xl text-gray-400'></i>
                    </span>
                    <input type="search" id="search_input" placeholder="Search 10000+ Products"
                        value="<?php echo e(request()->k); ?>" class="py-1 pl-1.5 w-full bg-transparent focus:outline-none">
                    <button onclick="search()" class="text-violet-500">Search</button>
                </div>
                <div class="flex items-center px-1.5 text-sm rounded border border-slate-300">
                    <span class="w-6 border-r border-slate-300">
                        <i class='bx bx-filter text-xl text-gray-400'></i>
                    </span>
                    <select onchange="sortBy(this)" class="py-1 pl-1.5 w-full bg-transparent focus:outline-none">
                        <option value="">Featured</option>
                        <option value="price_asc" <?php if(request()->sb == 'price_asc'): echo 'selected'; endif; ?>>Price: Low to High</option>
                        <option value="price_desc" <?php if(request()->sb == 'price_desc'): echo 'selected'; endif; ?>>Price: High to Low</option>
                        <option value="desc" <?php if(request()->sb == 'desc'): echo 'selected'; endif; ?>>Newest Arrivals</option>

                    </select>

                </div>

                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($item->variant->isNotEmpty()): ?>
                        <?php if (isset($component)) { $__componentOriginale95a270accfadada0901c28612b7c03d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale95a270accfadada0901c28612b7c03d = $attributes; } ?>
<?php $component = App\View\Components\Product\Card1::resolve(['product' => $item] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product.card1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Product\Card1::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale95a270accfadada0901c28612b7c03d)): ?>
<?php $attributes = $__attributesOriginale95a270accfadada0901c28612b7c03d; ?>
<?php unset($__attributesOriginale95a270accfadada0901c28612b7c03d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale95a270accfadada0901c28612b7c03d)): ?>
<?php $component = $__componentOriginale95a270accfadada0901c28612b7c03d; ?>
<?php unset($__componentOriginale95a270accfadada0901c28612b7c03d); ?>
<?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="md:col-span-3 flex flex-col justify-center items-center gap-3">
                        <img src="<?php echo e(asset('images/result-not-found.png')); ?>" alt="">
                        <h1 class="text-2xl font-bold text-gray-800">Result Not Found!</h1>
                        <p class="text-gray-400">Try to search with another query.</p>
                    </div>
                <?php endif; ?>
                <div class="md:col-span-3">
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </section>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online-shopping\resources\views/products.blade.php ENDPATH**/ ?>