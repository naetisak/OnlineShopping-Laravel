<?php $__env->startPush('scripts'); ?>
    <?php if (isset($component)) { $__componentOriginal1dddf896a7621481ec01e64a744db32e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1dddf896a7621481ec01e64a744db32e = $attributes; } ?>
<?php $component = App\View\Components\UrlGeneratorJs::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('url-generator-js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\UrlGeneratorJs::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1dddf896a7621481ec01e64a744db32e)): ?>
<?php $attributes = $__attributesOriginal1dddf896a7621481ec01e64a744db32e; ?>
<?php unset($__attributesOriginal1dddf896a7621481ec01e64a744db32e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1dddf896a7621481ec01e64a744db32e)): ?>
<?php $component = $__componentOriginal1dddf896a7621481ec01e64a744db32e; ?>
<?php unset($__componentOriginal1dddf896a7621481ec01e64a744db32e); ?>
<?php endif; ?>
    <script>
        let currentImage = 0;
        let color_id = '<?php echo e(request()->c ?? null); ?>';
        let size_id = '<?php echo e(request()->s ?? null); ?>';

        const selectColor = (cid) => {
            c = color_id ? null : cid;
            window.location.href = generateUrl({
                c
            })
        }
        const selectSize = (sid) => {
            s = size_id ? null : sid;
            window.location.href = generateUrl({
                s
            })
        }

        const viewImage = (e, index) => {

        currentImage = index;

        document.getElementById('bigImage').src = e.querySelector('img').src;
        }

        const nextPrevious = (index) => {

        i = currentImage + index;

        let images = document.getElementById('images').querySelectorAll('img');

        if (i >= images.length || i < 0) return;

        currentImage = i;

        let arr = [];

        images.forEach(element => arr.push(element.src));

        document.getElementById('bigImage').src = arr[currentImage];
        }

        const addToCart = () => {
            let count = '<?php echo e($product->variant->count()); ?>';
            if (count != 1) {
                cuteToast({
                    type: 'info',
                    message: 'Please select color & size'
                })
                return;
            }

            let variantId = '<?php echo e($product->variant[0]->id); ?>';
            if (!mCart.isInCart(variantId)) {
                mCart.add(variantId, 1);
                cuteToast({
                    type: 'success',
                    message: 'Added In Cart'
                })
            }

            document.getElementById('add_to_cart_btn').innerHTML = 'Added In Cart';
            cartCount();
            return true;
        }

        const buyNow = () => {
            if (addToCart()) {
                window.location.href = "<?php echo e(route('cart')); ?>";
            }
        }

        <?php if($product->variant->count() == 1): ?>
            let variantId = '<?php echo e($product->variant[0]->id); ?>';

            if (mCart.isInCart(variantId)) document.getElementById('add_to_cart_btn').innerHTML = 'Added In Cart';
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body_content'); ?>
    <section class="px-6 md:px-20 mt-6">

        <div class="flex flex-wrap md:flex-nowrap gap-6">
            
            <div class="shrink-0 md:w-auto w-full flex flex-col-reverse md:flex-row gap-4">
                <div id="images" class="flex md:flex-col gap-3 pb-1 md:pb-0 max-h-96 overflow-y-auto">
                    <?php $__currentLoopData = $product->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div onclick="viewImage(this,'<?php echo e($image->id); ?>')" 
                        class="bg-white rounded-md shadow p-1 cursor-pointer">
                        <img class="w-14" src="<?php echo e(asset('storage/' . $image->path)); ?>" alt="">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="h-96 relative bg-white rounded-md shadow-md p-3">
                    <img id="bigImage" class="h-full aspect-[2/3]" src="<?php echo e(asset('storage/' .$product->image[0]->path)); ?>" alt="">

                    <span onclick="nextPrevious(-1)"
                        class="absolute top-1/2 left-1 bg-white rounded-full w-5 h-5 shadow flex items-center justify-center">
                        <i class='bx bx-chevron-left text-xl text-gray-400 hover:text-violet-600 duration-200 cursor-pointer' ></i>
                    </span>

                    <span onclick="nextPrevious(1)"
                        class="absolute top-1/2 right-1 bg-white rounded-full w-5 h-5 shadow flex items-center justify-center">
                        <i class='bx bx-chevron-right text-xl text-gray-400 hover:text-violet-600 duration-200 cursor-pointer' ></i>
                    </span>
                </div>
            </div>
            

            

            <div class="w-ful flex flex-col gap-4">
                <div class="flex gap-3">
                    <?php
                        $discount = (($product->variant[0]->mrp - $product->variant[0]->selling_price) / $product->variant[0]->mrp) * 100;
                    ?>
                    <span class="bg-red-500 text-white rounded px-2 text-xs"><?php echo e(round($discount, 2)); ?>% Off</span>
                    <span class="text-amber-500 text-sm"><i class='bx bx-star'></i> 4.5</span>
                </div>
                
                <h2 class="text-lg font-medium text-gray-800"> <?php echo e($product->title); ?></h2>
                <div class="text-sn text-gray-800">
                    <p><span class="text-gray-400 ">SKU:</span> <?php echo e($product->variant[0]->sku); ?></p>
                    <p><span class="text-gray-400 ">Brand:</span> <?php echo e($product->brand->name); ?></p>
                </div>

                
                
                <div>
                    <span class="text-rose-500 font-bold text-xl">$<?php echo e($product->variant[0]->selling_price); ?></span>
                    <sub class="text-gray-400"><strike>$<?php echo e($product->variant[0]->mrp); ?></strike></sub>
                </div>

                
                <div>
                    <p class="text-gray-400">Colors:</p>
                    <div class="flex gap-1">
                        <?php $__currentLoopData = $product->variant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span onclick="selectColor('<?php echo e($item->color->id); ?>')"
                                style="background-color: <?php echo e($item->color->code); ?>"
                                class="w-5 h-5 cursor-pointer rounded-full">&nbsp;</span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                

                
                <div>
                    <p class="text-gray-400">Sizes:</p>
                    <div class="flex gap-1 text-gray-400 text-sm">
                        <?php $__currentLoopData = $product->variant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span onclick="selectSize('<?php echo e($item->size->id); ?>')"
                                class="flex justify-center cursor-pointer items-center w-5 h-5 rounded-full border border-gray-400"><?php echo e($item->size->code); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a href="#" class="text-gray-400 text-xs">Size Guide</a>
                </div>
                

                
                
                

                
                <div class="flex items-center gap-4">
                    <span class="bg-white shadow-md rounded-full w-8 h-8 flex items-center justify-center">
                        <i class='bx bx-heart text-2xl text-gray-500' ></i>
                    </span>
                    <button onclick="addToCart()" id="add_to_cart_btn"
                        class="border border-violet-600 rounded w-28 text-center drop-shadow font-medium text-violet-600 py-0.5">Add
                        to Cart</button>
                    <button onclick="buyNow()"
                        class="border border-violet-600 rounded w-28 text-center drop-shadow font-medium text-white bg-violet-600 py-0.5">Buy
                        Now</button>
                </div>
                
                
            </div>
            
        </div>

        
        <div>
            <h3 class="text-lg text-gray-400 font-medium my-6">Product Description</h3>
            <div class="text-gray-600">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus illum excepturi itaque rerum soluta expedita explicabo
                vero. Unde, aut? Architecto sapiente libero, est nulla qui minima sit natus quis sed tempora ad accusamus perferendis
                fugit similique voluptate nemo impedit vel ab voluptatibus soluta praesentium facere voluptates fugiat? Incidunt libero 
                vel natus molestiae nulla. Debitis dolores officia cupiditate reprehenderit earum nemo fugit voluptatem, rem alias
                nihil, dolor, quo laudantium aliquam vel dicta blanditiis odio quia nisi recusandae autem aspernatur delectus quae 
                voluptatum pariatur? Repellendus, labore deserunt! Dignissimos voluptatibus enim magni necessitatibus odit illum 
                numquam vitae aut consequuntur, iure quos, provident ipsa.
            </div>
        </div>
        

        <section class="mt-6">
            <h3 class="text-gray-800 font-medium mb-2">Featured Product</h3>
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->variant->isNotEmpty()): ?>
                        <?php if (isset($component)) { $__componentOriginale95a270accfadada0901c28612b7c03d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale95a270accfadada0901c28612b7c03d = $attributes; } ?>
<?php $component = App\View\Components\Product\Card1::resolve(['product' => $item] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product.card1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Product\Card1::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale95a270accfadada0901c28612b7c03d)): ?>
<?php $attributes = $__attributesOriginale95a270accfadada0901c28612b7c03d; ?>
<?php unset($__attributesOriginale95a270accfadada0901c28612b7c03d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale95a270accfadada0901c28612b7c03d)): ?>
<?php $component = $__componentOriginale95a270accfadada0901c28612b7c03d; ?>
<?php unset($__componentOriginale95a270accfadada0901c28612b7c03d); ?>
<?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online-shopping\resources\views/product_detail.blade.php ENDPATH**/ ?>