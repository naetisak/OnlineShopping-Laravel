<?php $__env->startSection('body_content'); ?>
    <div class="px-6 md:min-h-screen md:px-20 mt-6 grid grid-cols-1 md:grid-cols-6 gap-4">
        <div>
            <ul class="flex md:flex-col flex-wrap  justify-between gap-3 md:gap-1" id="tabLinks">
                <li><a class="flex" href="<?php echo e(route('account.index')); ?>">My Profile</a></li>
                <li><a class="flex text-violet-600 underline" href="<?php echo e(route('account.index', ['tab' => 'orders'])); ?>">My Orders</a></li>
                <li><a class="flex" href="<?php echo e(route('account.index', ['tab' => 'address'])); ?>">My
                        Address</a></li>
                <?php if(auth()->guard()->check()): ?>
                    <li><a href="<?php echo e(route('logout')); ?>" class="flex">Logout</a></li>
                <?php endif; ?>
            </ul>
        </div>

        
        <div class="md:col-span-5">
            <?php if(auth()->guard()->check()): ?>
                <section class="border border-slate-300 rounded px-4 pt-2 pb-4">
                    <h3 class="text-gray-900 font-medium">Order Details <?php echo e(str_pad($order->id, 8, '0', STR_PAD_LEFT)); ?></h3>
                    <hr class="mb-3">

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                        <div class="flex gap-1 border border-slate-300 rounded">
                            <span class="flex-[2] bg-slate-400 px-2 text-white font-medium rounded-l">Order ID</span>
                            <p class="flex-[3]"><?php echo e(str_pad($order->id, 8, '0', STR_PAD_LEFT)); ?></p>
                        </div>

                        <div class="flex gap-1 border border-slate-300 rounded">
                            <span class="flex-[2] bg-slate-400 px-2 text-white font-medium rounded-l">Order Status</span>
                            <p class="flex-[3]"><?php echo e($order->status); ?></p>
                        </div>

                        <div class="flex gap-1 border border-slate-300 rounded">
                            <span class="flex-[2] bg-slate-400 px-2 text-white font-medium rounded-l">Payment Status</span>
                            <p class="flex-[3]"><?php echo e($order->payment_status); ?></p>
                        </div>

                        <div class="flex gap-1 border border-slate-300 rounded">
                            <span class="flex-[2] bg-slate-400 px-2 text-white font-medium rounded-l">Total $</span>
                            <p class="flex-[3]"><?php echo e($order->total_amount); ?></p>
                        </div>

                        <div class="flex gap-1 border border-slate-300 rounded">
                            <span class="flex-[2] bg-slate-400 px-2 text-white font-medium rounded-l">Discount $</span>
                            <p class="flex-[3]"><?php echo e($order->discount_amount); ?></p>
                        </div>

                        <div class="flex gap-1 border border-slate-300 rounded">
                            <span class="flex-[2] bg-slate-400 px-2 text-white font-medium rounded-l">Payment $</span>
                            <p class="flex-[3]"><?php echo e($order->total_amount); ?></p>
                        </div>
 
                    </div>

                    <h3 class="text-gray-900 font-medium mt-8">Ordered Items</h3>
                    <hr class="mb-3">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex gap-4">
                            <div class="bg-gray-100 rounded shadow p-2">
                                <img class="w-20" src="<?php echo e(asset('storage/'. $item->variant->product->oldestImage->path)); ?>" alt="">
                            </div>
                            <div class="flex flex-col gap-0.5">
                                <h3 class="text-lg font-medium text-gray-800"><?php echo e($item->variant->product->title); ?></h3>
                                <div class="text-gray-400 text-sm flex items-center gap-2">
                                    <p class="flex items-center gap-1">
                                        Color:
                                        <span style="background-color: <?php echo e($item->variant->color->code); ?>" class="w-4 h-4 rounded-full">&nbsp;</span>
                                    </p>
                                    <p>Size:  <?php echo e($item->variant->size->code); ?></p>
                                </div>
                                <p class="text-gray-400">
                                    Quantity: <span class="text-gray-800"><?php echo e($item->qty); ?></span>
                                </p>
                                <p class="text-gray-400">
                                    Price: $<span class="text-gray-800"><?php echo e($item->price); ?></span>
                                </p>
                                <p class="text-gray-400">
                                    Total Price: $<span class="text-gray-800"><?php echo e($item->price * $item->qty); ?></span>
                                </p>
                            </div>
                        </div>     
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </section>
            <?php else: ?>
                <div class="border w-full py-10 flex justify-center rounded-md items-center">
                    <button type="button" class="text-violet-500 font-medium" onclick="toggleLoginPopup()">Login
                        to access your account</button>
                </div>
            <?php endif; ?>
        </div>
        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online-shopping\resources\views/show_order.blade.php ENDPATH**/ ?>