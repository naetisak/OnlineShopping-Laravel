<?php

return [
    'prefix' => 'dpanel',
    'first_name' => 'Dpanel',
    'last_name' => 'Admin',
    'email' => 'dpanel@localhost.com',
    'password' => 'dpanel',
    'dpanel_access_roles' => [
        'admin',
    ]
];
